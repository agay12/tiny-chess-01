// The run record: what a reviewer needs to recreate an entry's run and check that it is real, beside the
// sessions that show the run itself. Four parts:
//   prompt         the person's own opening prompt, word for word (never an agent's summary, hand-off or brief),
//                  with how it reached the agent (RUN_PROMPT_ORIGINS) and, unless they typed it, what started it
//   system_prompt  where the system prompt the agent ran under is: uploaded as a context file, carried in a
//                  session, or withheld with a one-line reason
//   instructions   whether the instruction files the agent ran under (CLAUDE.md, AGENTS.md, rules, skills, settings:
//                  a bundle's context files of every kind but system-prompt) are collected in the upload, the agent
//                  ran with none, or they are withheld with a one-line reason; optional, since a kit below level 14
//                  (cli/version.ts INSTRUCTIONS_KIT_LEVEL) writes no such field and its records still parse
//   mcp_servers    every MCP server the agent used: its name as the agent's tool list shows it and how to reach it
//                  again (a URL, or a launch command and package), or builtin for one shipped inside the harness
// The rest of the system setup (harness and version, provider, model, effort) is the agent facts, BundleDeclared,
// defined here and kept in a bundle's manifest.declared (contracts/bundle.ts re-exports it). A bundle carries the
// record as manifest.run (contracts/bundle.ts); a loose upload, which has no manifest, carries it as one more file
// named LOOSE_RUN_FILE_NAME holding a LooseRunFile: the record plus the agent facts under `declared`. A strict entry's
// run file (one beside sealed recordings) may also list, under `context`, the context files that ride beside it as their
// own parts, outside the signed recordings (RunContextFile): the run file names them, so the signature over it binds
// them; they are never evidence, and they change no status above (an instructions file listed there does not make
// instructions `collected`, nor a system-prompt file system_prompt `uploaded`: each status keeps its meaning), and a
// list that breaks RunContextList reads as none, never a reason to refuse the run file.
//
// A leaf importing only zod: the kit's one-file CLI inlines it (server/kit/cli-bundle.ts), and contracts/bundle.ts
// imports it, so it imports nothing from contracts/bundle.ts (a cycle would leave one side's schema undefined at
// load) nor contracts/competition.ts (MCP_REGISTRY_NAME_RE below copies that file's McpRegistryName pattern).

import { z } from 'zod';

/** The record's format string; a change that would refuse an earlier record gets a new one. */
export const RUN_RECORD_FORMAT = 'makefun-run/1';
/** The loose upload's run file: its name exactly, beside the transcripts. */
export const LOOSE_RUN_FILE_NAME = 'makefun-run.json';
/** The longest opening prompt, characters. */
export const RUN_PROMPT_MAX_CHARS = 100_000;
/** The most MCP servers one record lists. */
export const RUN_MCP_MAX_SERVERS = 32;
/** The most arguments a stdio server's launch command takes. */
export const RUN_MCP_MAX_ARGS = 32;
/** The longest MCP server URL, characters. */
export const RUN_MCP_MAX_URL_CHARS = 2048;

const notBlank = (s: string): boolean => s.trim() !== '';
const oneLine = (s: string): boolean => !/[\r\n\u2028\u2029]/.test(s);
/** One line of 1..max characters, not blank. */
const line = (max: number) => z.string().min(1).max(max).refine((s) => notBlank(s) && oneLine(s), 'one line: not blank, no line break');

/**
 * How the opening prompt reached the agent:
 *   typed       the person typed it as the first message of an uploaded session
 *   scheduled   a scheduled or automated run fired it: the text is the task's configured prompt
 *   handed-off  another agent session started this one: the text is the person's prompt to THAT earlier session
 *   other       it reached the agent another way
 */
export const RUN_PROMPT_ORIGINS = ['typed', 'scheduled', 'handed-off', 'other'] as const;
export const RunPromptOrigin = z.enum(RUN_PROMPT_ORIGINS);

/**
 * The person's opening prompt. `text` is their words as they wrote them, any number of lines; `via` is one line
 * saying what started the run (the schedule, the session that handed off, the automation): required unless the
 * origin is typed, and null when it is.
 */
export const RunPrompt = z
  .strictObject({
    text: z.string().min(1).max(RUN_PROMPT_MAX_CHARS).refine(notBlank, 'not blank'),
    origin: RunPromptOrigin,
    via: line(300).nullable(),
  })
  .superRefine((p, ctx) => {
    if (p.origin === 'typed' && p.via !== null) ctx.addIssue({ code: 'custom', path: ['via'], message: 'a typed prompt has no via: null' });
    if (p.origin !== 'typed' && p.via === null) ctx.addIssue({ code: 'custom', path: ['via'], message: `a ${p.origin} prompt names what started it in via (one line)` });
  });

/**
 * Where the system prompt is:
 *   uploaded    a context file of kind system-prompt (bundle --system-prompt <file>) holds it
 *   in-session  an uploaded session carries it
 *   withheld    it is not uploaded, for the one-line reason in `why`
 */
export const SYSTEM_PROMPT_STATUSES = ['uploaded', 'in-session', 'withheld'] as const;
export const SystemPromptStatus = z.enum(SYSTEM_PROMPT_STATUSES);

/** The system prompt's status; `why` is required when it is withheld and null otherwise. */
export const RunSystemPrompt = z
  .strictObject({
    status: SystemPromptStatus,
    why: line(300).nullable(),
  })
  .superRefine((s, ctx) => {
    if (s.status === 'withheld' && s.why === null) ctx.addIssue({ code: 'custom', path: ['why'], message: 'a withheld system prompt says why, in one line' });
    if (s.status !== 'withheld' && s.why !== null) ctx.addIssue({ code: 'custom', path: ['why'], message: `an ${s.status} system prompt has no why: null` });
  });

/**
 * Whether the instruction files the agent ran under (CLAUDE.md, AGENTS.md, rules, skills, settings) are in the upload:
 *   collected  the upload carries them: at least one context file of a kind other than system-prompt
 *   none       the agent ran with no instruction file, and the upload carries none
 *   withheld   they are not uploaded, for the one-line reason in `why`
 */
export const INSTRUCTIONS_STATUSES = ['collected', 'none', 'withheld'] as const;
export const InstructionsStatus = z.enum(INSTRUCTIONS_STATUSES);

/** The instruction files' status, the twin of RunSystemPrompt: `why` is required when they are withheld and null otherwise. */
export const RunInstructions = z
  .strictObject({
    status: InstructionsStatus,
    why: line(300).nullable(),
  })
  .superRefine((s, ctx) => {
    if (s.status === 'withheld' && s.why === null) ctx.addIssue({ code: 'custom', path: ['why'], message: 'withheld instruction files say why, in one line' });
    if (s.status !== 'withheld' && s.why !== null) ctx.addIssue({ code: 'custom', path: ['why'], message: `instruction files marked ${s.status} have no why: null` });
  });

/**
 * What a context file riding beside a strict entry's run file is (LooseRunFile.context):
 *   begun-before   a session the agent began before the recording did, which the seal left out: never evidence
 *   instructions   an instruction file the agent ran under (CLAUDE.md, AGENTS.md, rules, skills, settings)
 *   system-prompt  the system prompt the agent ran under, as a file
 * server/db/schema.ts TRANSCRIPT_CONTEXT_UPLOAD_ROLES, the roles submission.transcript_context_upload stores, is this list.
 */
export const RUN_CONTEXT_ROLES = ['begun-before', 'instructions', 'system-prompt'] as const;
export const RunContextRole = z.enum(RUN_CONTEXT_ROLES);
/** The most context files one run file lists. */
export const RUN_CONTEXT_MAX_FILES = 512;
/** The longest name a context file goes by, characters. */
export const RUN_CONTEXT_MAX_NAME_CHARS = 512;

/**
 * Why `name` is not a name a context file may go by, or null when it is: a relative path of `/`-separated parts, none
 * empty, `.` or `..`, with no backslash, control character or line break (two CLAUDE.md files from two directories
 * go by two names). It is the file name of the multipart part that carries the file.
 */
export function runContextNameIssue(name: string): string | null {
  if (name.length === 0 || name.length > RUN_CONTEXT_MAX_NAME_CHARS) return `is not 1 to ${RUN_CONTEXT_MAX_NAME_CHARS} characters`;
  if (/[\\\u0000-\u001f\u007f\u2028\u2029]/.test(name)) return 'holds a backslash, a control character or a line break';
  if (name.split('/').some((part) => part === '' || part === '.' || part === '..')) return 'is not a relative path of non-empty parts (no leading or doubled /, no . or ..)';
  return null;
}

const RunContextName = z.string().superRefine((name, ctx) => {
  const why = runContextNameIssue(name);
  if (why !== null) ctx.addIssue({ code: 'custom', message: `a context file's name: this one ${why}` });
});

/**
 * One context file a strict entry's run file names: `name` its part's file name (unique in the list), `sha256` and
 * `bytes` the file's as sent, `role` RUN_CONTEXT_ROLES, and `kind`, when the kit names one, what narrows the role (the
 * harness a begun-before session came from, an instructions file's context kind: contracts/bundle.ts CONTEXT_KINDS).
 */
export const RunContextFile = z.strictObject({
  name: RunContextName,
  sha256: z.string().regex(/^[0-9a-f]{64}$/, 'a sha256: 64 lowercase hex characters'),
  bytes: z.number().int().min(0).max(Number.MAX_SAFE_INTEGER),
  role: RunContextRole,
  kind: z
    .string()
    .regex(/^[a-z0-9][a-z0-9._-]{0,63}$/, 'a kind: 1 to 64 lowercase letters, digits, dots, dashes or underscores')
    .optional(),
});

/**
 * How the agent reached an MCP server:
 *   stdio            it launched the server: `command`, with `args`
 *   streamable-http  it connected to `url` over Streamable HTTP
 *   sse              it connected to `url` over the older HTTP+SSE transport
 *   builtin          the server ships inside the harness (Claude Code's `ide`, Cosmos's `cosmos`): the name alone
 */
export const MCP_RUN_TRANSPORTS = ['stdio', 'streamable-http', 'sse', 'builtin'] as const;
export const McpRunTransport = z.enum(MCP_RUN_TRANSPORTS);

/** contracts/competition.ts McpRegistryName's pattern, copied to keep this file a leaf. */
const MCP_REGISTRY_NAME_RE = /^[a-zA-Z0-9.-]+\/[a-zA-Z0-9._-]+$/;
/** A server's name in the MCP Registry (registry.modelcontextprotocol.io): a reverse-DNS namespace, a slash and a name. */
const RunMcpRegistryName = z
  .string()
  .min(3)
  .max(200)
  .regex(MCP_REGISTRY_NAME_RE, 'expected an MCP Registry name: a reverse-DNS namespace, a slash and a name, such as io.github.owner/server');

/** Why `u` is not an MCP server URL a record may hold, or null when it is: http or https, no user name or password in it. */
export function mcpUrlIssue(u: string): string | null {
  if (u.length > RUN_MCP_MAX_URL_CHARS) return `is longer than ${RUN_MCP_MAX_URL_CHARS} characters`;
  if (!oneLine(u) || u.trim() !== u) return 'holds a line break or surrounding space';
  let url: URL;
  try {
    url = new URL(u);
  } catch {
    return 'is not a URL';
  }
  if (url.protocol !== 'https:' && url.protocol !== 'http:') return 'is not http or https';
  if (url.username !== '' || url.password !== '') return 'holds a user name or password';
  return null;
}

const RunMcpUrl = z.string().superRefine((u, ctx) => {
  const why = mcpUrlIssue(u);
  if (why !== null) ctx.addIssue({ code: 'custom', message: `an http(s) URL with no user name or password: this one ${why}` });
});

/**
 * One MCP server the agent used.
 *   name           its name as the agent's tool list shows it (`github` for `mcp__github__*`), matched to a used
 *                  name by mcpNameKey; unique in the record by it
 *   transport      MCP_RUN_TRANSPORTS
 *   url            where a streamable-http or sse server answers (required there, absent elsewhere)
 *   command, args  how a stdio server is launched (command required there; both absent elsewhere)
 *   package        what it runs from, when a package names it: `npm:@scope/pkg@1.2.3`, `pypi:name==1.0`
 *   registry_name  its MCP Registry name, or null when it is not listed there
 * A builtin server carries its name alone. No field holds an env value, a header, an API key, a token or any other
 * credential, and none may be added: the record is for recreating the run, and a reviewer supplies their own.
 */
export const RunMcpServer = z
  .strictObject({
    name: line(64),
    transport: McpRunTransport,
    url: RunMcpUrl.optional(),
    command: line(200).optional(),
    args: z.array(z.string().max(400).refine(oneLine, 'one line: no line break')).max(RUN_MCP_MAX_ARGS).optional(),
    package: line(200).optional(),
    registry_name: RunMcpRegistryName.nullable().optional(),
  })
  .superRefine((m, ctx) => {
    const issue = (path: string, message: string) => ctx.addIssue({ code: 'custom', path: [path], message });
    const remote = m.transport === 'streamable-http' || m.transport === 'sse';
    if (remote && m.url === undefined) issue('url', `a ${m.transport} server names its url`);
    if (!remote && m.url !== undefined) issue('url', `a ${m.transport} server has no url`);
    if (m.transport === 'stdio' && m.command === undefined) issue('command', 'a stdio server names the command it is launched with');
    if (m.transport !== 'stdio' && m.command !== undefined) issue('command', `a ${m.transport} server has no command`);
    if (m.transport !== 'stdio' && m.args !== undefined) issue('args', `a ${m.transport} server has no args`);
    if (m.transport === 'builtin' && m.package !== undefined) issue('package', 'a builtin server carries its name alone');
    if (m.transport === 'builtin' && m.registry_name !== undefined && m.registry_name !== null) issue('registry_name', 'a builtin server carries its name alone');
  });

/**
 * How a used server's name is matched to a declared one: lowercase, with `-`, `_`, ` ` and `.` all read as `_`
 * (Claude Code writes the server `claude.ai Gmail` into its tool names as `claude_ai_Gmail`).
 */
export function mcpNameKey(name: string): string {
  return name.toLowerCase().replace(/[-_ .]/g, '_');
}

/** How an entrant says the agent was run (`makefun bundle`'s flags); unverified. A bundle keeps it as manifest.declared. */
export const BundleDeclared = z.strictObject({
  harness: z.string().max(64).nullable(),
  harness_version: z.string().max(64).nullable(),
  model: z.string().max(128).nullable(),
  provider: z.string().max(128).nullable(),
  reasoning_effort: z.string().max(32).nullable(),
  notes: z.string().max(2000).nullable(),
});

const runRecordShape = {
  format: z.literal(RUN_RECORD_FORMAT),
  prompt: RunPrompt,
  system_prompt: RunSystemPrompt,
  /**
   * The instruction files' status. Optional: a kit below level 14 writes none, and a required field would make every
   * record it wrote unparseable (the schema is strict); the site's check notes its absence and never fails on it.
   */
  instructions: RunInstructions.optional(),
  /** Every MCP server the agent used; empty when it used none. */
  mcp_servers: z.array(RunMcpServer).max(RUN_MCP_MAX_SERVERS),
};

/** A server is listed once: two names with one mcpNameKey are the same server. */
function uniqueServers(
  r: { mcp_servers: ReadonlyArray<{ name: string }> },
  ctx: { addIssue: (issue: { code: 'custom'; path: (string | number)[]; message: string }) => void },
): void {
  const seen = new Map<string, string>();
  r.mcp_servers.forEach((m, i) => {
    const key = mcpNameKey(m.name);
    const first = seen.get(key);
    if (first !== undefined) ctx.addIssue({ code: 'custom', path: ['mcp_servers', i, 'name'], message: `${m.name} is the server ${first} already listed` });
    else seen.set(key, m.name);
  });
}

/** The run record (see the header). */
export const RunRecord = z.strictObject(runRecordShape).superRefine(uniqueServers);

/**
 * A strict entry's context list as its writer must make it: RunContextFile entries, each name once (two entries with
 * one name are refused, naming the second), at most RUN_CONTEXT_MAX_FILES. A kit checks the list it writes with this;
 * LooseRunFile reads a list that fails it as absent.
 */
export const RunContextList = z
  .array(RunContextFile)
  .max(RUN_CONTEXT_MAX_FILES)
  .superRefine((list, ctx) => {
    const seen = new Set<string>();
    list.forEach((c, i) => {
      if (seen.has(c.name)) ctx.addIssue({ code: 'custom', path: [i, 'name'], message: `${c.name} is listed already` });
      else seen.add(c.name);
    });
  });

/**
 * A loose upload's makefun-run.json: the run record and the agent facts a bundle would keep in manifest.declared, and,
 * for a strict entry, the context files riding beside it (RunContextList; optional: a kit that sends none writes none,
 * and every run file written before it still parses). Only the run file carries `context`: the run record a bundle's
 * manifest holds, and the one ingest stores (transcripts/ingest.ts runRecordOf), never do.
 *
 * `context` is never a reason to refuse a run file, and so never one to refuse an entry: a value that is not a whole
 * RunContextList (null, a bad name, a name twice, past RUN_CONTEXT_MAX_FILES) reads as no list (`.catch(undefined)`:
 * the key parses to undefined), the intake then takes no context part, and every other field stays exactly as strict.
 * The whole list goes rather than its bad entries, so what the server takes is either the list the signed run file
 * names, as written, or nothing.
 */
export const LooseRunFile = z
  .strictObject({ ...runRecordShape, declared: BundleDeclared, context: RunContextList.optional().catch(undefined) })
  .superRefine(uniqueServers);

/**
 * Openings of a first user message that an agent or a harness wrote, not the person: a hand-off from another
 * session, or a continuation after the context was compacted. Each is an exact known opening, anchored at the
 * start: a false match would reject an honest entry's typed prompt, so nothing broader goes here.
 */
export const HANDOFF_PROMPT_MARKERS: readonly RegExp[] = [
  // A session another agent session started (the example entry https://make.fun/s/01a1dce6-af3f-70d6-9c6b-7f161cd050c7,
  // claude-code 2.1.321: its one session opens with this hand-off).
  /^\s*Background \(from the session that started this one\)/i,
  // Claude Code's continuation after compaction (tests/fixtures/transcripts/claude-stream/cowork-audit.jsonl,
  // tests/fixtures/transcripts/qoder/projects/-Users-user-projects-wordcount/5f0c2a9e-3b7d-4e1f-8a6c-9d2b4e7f1a30.jsonl).
  /^\s*This session is being continued from a previous conversation/i,
  // Goose's continuation after compaction (tests/fixtures/transcripts/goose/rows.json, its context_mgmt message).
  /^\s*Your context was compacted\. The previous message contains a summary of the conversation so far/i,
  // Devin's lead handing work to its sidekick (tests/fixtures/transcripts/devin/rows.json).
  /^\s*<lead_handoff>/i,
  // Hermes Agent's compaction hand-off, agent/context_compressor.py SUMMARY_PREFIX and LEGACY_SUMMARY_PREFIX
  // (tests/fixtures/transcripts/hermes/rows.json, the first row of session 20261108_150210_778899). The reader flags that
  // row itself (transcripts/hermes.ts: injected, compact_summary), so no session yields it as an opening; this holds a
  // record's own text to it, whatever its origin.
  /^\s*\[CONTEXT COMPACTION\b/,
  /^\s*\[CONTEXT SUMMARY\]:/,
];

/** Whether `text` opens as an agent's or a harness's hand-off rather than the person's own words (HANDOFF_PROMPT_MARKERS). */
export function isHandoffPrompt(text: string): boolean {
  return HANDOFF_PROMPT_MARKERS.some((re) => re.test(text));
}

/** `s` as samePrompt compares it: NFC, every run of whitespace (line breaks included) one space, trimmed. */
export function normalizePrompt(s: string): string {
  return s.normalize('NFC').replace(/\s+/g, ' ').trim();
}

/** Whether two prompts say the same words: equal once each is normalizePrompt'd. */
export function samePrompt(a: string, b: string): boolean {
  return normalizePrompt(a) === normalizePrompt(b);
}

export type RunPromptOriginT = z.infer<typeof RunPromptOrigin>;
export type RunPromptT = z.infer<typeof RunPrompt>;
export type SystemPromptStatusT = z.infer<typeof SystemPromptStatus>;
export type RunSystemPromptT = z.infer<typeof RunSystemPrompt>;
export type InstructionsStatusT = z.infer<typeof InstructionsStatus>;
export type RunInstructionsT = z.infer<typeof RunInstructions>;
export type McpRunTransportT = z.infer<typeof McpRunTransport>;
export type RunMcpServerT = z.infer<typeof RunMcpServer>;
export type RunRecordT = z.infer<typeof RunRecord>;
export type LooseRunFileT = z.infer<typeof LooseRunFile>;
export type RunContextRoleT = z.infer<typeof RunContextRole>;
export type RunContextFileT = z.infer<typeof RunContextFile>;
export type BundleDeclaredT = z.infer<typeof BundleDeclared>;
